A0 Without urbanization  
A1 Consideration of urbanization	

B0 Without consideration of  Climate change  
B1 "The low emission scenario B2"	The precipiation increase 22,9%, the sea level rise 13 cm  	
B2 "The high emission scenario A1"	The precipiation increase 44,3%, the sea level rise 26 cm  	

C0 "100% volume Reservoir regulation for flood control capacity (Flood control water level: Ta Trach reservoir: 25, 0 m; Binh Dien: 72,4 m; Huong Dien: 50,6m"  
C1 "50% volume Reservoir regulation for flood control capacity (Flood control water level: Ta Trach reservoir: 42 m; Binh Dien: 82,5 m; Huong Dien: 56 m"  
C2 "0% volume Reservoir regulation for flood control capacity (Flood control water level: Ta Trach reservoir: 45 m; Binh Dien: 85 m; Huong Dien: 58 m"  
